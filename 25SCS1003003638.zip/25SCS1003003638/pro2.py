import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Synthetic dataset generation (if no file is provided)
np.random.seed(42)
n = 500
timestamps = pd.date_range(start="2023-01-01", periods=n, freq="H")
renewable_gen = np.random.uniform(100, 500, n)
total_gen = renewable_gen + np.random.uniform(200, 800, n)
demand = total_gen + np.random.uniform(-50, 50, n)
wind_speed = np.random.uniform(2, 15, n)
solar_irradiance = np.random.uniform(100, 1000, n)

data = pd.DataFrame({
    "timestamp": timestamps,
    "renewable_gen": renewable_gen,
    "total_gen": total_gen,
    "demand": demand,
    "wind_speed": wind_speed,
    "solar_irradiance": solar_irradiance
})

# Calculate renewable penetration rate
data["penetration_rate"] = data["renewable_gen"] / data["total_gen"]

# Features and labels
X = data[["renewable_gen", "total_gen", "demand", "wind_speed", "solar_irradiance"]]
y = data["penetration_rate"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Models
lin_reg = LinearRegression()
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)

# Train models
lin_reg.fit(X_train, y_train)
rf_reg.fit(X_train, y_train)

# Predictions
y_pred_lin = lin_reg.predict(X_test)
y_pred_rf = rf_reg.predict(X_test)

# Evaluation
print("Linear Regression MSE:", mean_squared_error(y_test, y_pred_lin))
print("Linear Regression R²:", r2_score(y_test, y_pred_lin))

print("Random Forest MSE:", mean_squared_error(y_test, y_pred_rf))
print("Random Forest R²:", r2_score(y_test, y_pred_rf))

# Visualization
plt.figure(figsize=(10, 5))
plt.plot(y_test.values[:50], label="Actual", marker="o")
plt.plot(y_pred_lin[:50], label="Linear Predicted", linestyle="--")
plt.plot(y_pred_rf[:50], label="RF Predicted", linestyle="--")
plt.xlabel("Sample Index")
plt.ylabel("Penetration Rate")
plt.title("Renewable Penetration Rate Prediction")
plt.legend()
plt.tight_layout()
plt.show()
